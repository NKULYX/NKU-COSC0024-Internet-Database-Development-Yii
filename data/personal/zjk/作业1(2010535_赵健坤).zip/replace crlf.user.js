// ==UserScript==
// @name         replace crlf
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://fanyi.youdao.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=deepl.com
// @grant        none
// ==/UserScript==



(function() {
    'use strict';

    window.setInterval(function(){
    var element = document.getElementsByClassName("src");
    if(element.length==0){
        var initText = document.getElementById("js_fanyi_input").innerHTML;
        if(initText!=null){
            for (let i = 0; i < initText.length; i++) {
                if (initText.indexOf('\n')) initText = initText.replace('\n', ' ');
                if (initText.indexOf('\r')) initText = initText.replace('\r', ' ');
            }
            document.getElementById("js_fanyi_input").innerHTML = initText;
        }
    }
    else if(element!=null){
        var newText = "";
        for(let i = 0;i<element.length;i++){
            newText.concat(element[i].innerHTML);
            console.log(newText);
        }
        element[0].innerHTML = newText;
    }
    }, 1000);
})();