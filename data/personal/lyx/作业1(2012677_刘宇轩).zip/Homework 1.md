# Homework 1

## 1. 针对任意网页，调研其不同方式请求

这里我们选择访问GitHub，在点击了我的主页之后，通过F12打开开发者工具，来捕捉网页加载过程中的请求内容。如图所示。

![image-20230207192200879](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207192200879.png)

可以看到，第一条请求就是通过Get方法来获取网页的HTML文件，进而加载和渲染网页内容。由于在网页中引用了非常多的网络资源，因此在请求完主页之后，浏览器在解析的过程中会依次去请求网页资源，下面的一连串请求就是去请求主页中引用的网络资源，并且这一系列的请求都是通过Get方法实现的。

接下来我们看到了一个stats的请求，推测其是向GitHub服务器推送一些用户状态信息等。

![image-20230207192547916](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207192547916.png)

通过截图也可以看到，这个请求是通过Post方法完成的。一般向服务器推送数据信息时，出于安全考虑都会采用Post方式，因为此时数据不用在Url中明文传输。可以从负载中看到这一次请求携带的数据信息

![image-20230207192716354](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207192716354.png)

## 针对任意网页，使用JQuery触发事件

1. 还是针对GitHub，我们使用JQuery将用户名进行修改，通过class查找到用户名对应的HTML元素，由于用户名是包含在span标签中的，因此可以使用textContent方法来获取用户名的内容，由于我们想要修改用户名，所以直接对其进行赋值操作即可。修改前后的对比如图

![image-20230207193729630](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207193729630.png)

![image-20230207193306948](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207193306948.png)

2. 接下来，打算修改一下contribution统计，进而掩盖掉一年中大多数时间都在摸鱼的不良显现。通过开发者工具可以检查到contribution对应的是一个svg图标，里面的每一天都对应了一个g标签，而对于用贡献的日期，其data-level不为0，没有贡献的日期，data-level为0。因此一个最简单的思路就是将所有g标签的data-level属性为0的元素修改属性值为1即可。

![image-20230207194055487](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207194055487.png)

```javascript
let list = document.querySelectorAll('rect');
for (let i = 0; i < list.length; i++) {
    if(list[i].getAttribute('data-level') == '0') {
        list[i].setAttribute('data-level' , '1');
    }
}
```

![image-20230207200855808](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207200855808.png)

3. 接下来尝试给搜索框加上一个hook，即点击搜索框的时候执行跳转操作。

![image-20230207202106194](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207202106194.png)

![image-20230207202123868](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207202123868.png)

![image-20230207202136207](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207202136207.png)

## 完成一个插件

鉴于现在的B站用户在浏览视频的过程中存在着大量的白嫖现象，为了从根本上解决用户看视频不投币的不良行为，特意开发了一款自动点赞投币和收藏的三连插件。

其实现原理十分简单，就是对于页面上的点赞、投币和收藏按钮执行点击操作。

首先打开开发者工具，检查元素，确定这三个按钮对应的元素标签。

![image-20230207202646235](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207202646235.png)

![image-20230207202743053](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207202743053.png)

可以看到，点赞、投币和收藏分别对应class为like coin collect，而当执行完点赞操作之后，对应元素的类别中会增加on类别，用以区分点赞前后的状态。而为了避免重复点赞导致取消的问题，考虑首先判断点赞标签的class是否有on属性，如果没有的话，再进行点击操作，转换为JavaScript代码如下

```javascript
// 没点赞则点赞
if(document.getElementsByClassName('like on')[0] == null) {
    document.querySelector('.like').click();
}
```

需要注意的是，在执行投币的时候略有差异，在点击了投币之后，会弹出一个新的窗口，需要选择投币的数量，这里直接默认，通过点击确定按钮完成投币操作即可。转换为JavaScript代码如下

```javascript
// 没投币则投币
if(document.getElementsByClassName('coin on')[0] == null) {
    document.querySelector('.coin').click();
    document.querySelector('.bi-btn').click();
    alert('休想白嫖！');
}
```

为了避免有些用户投机取巧，在完成了三连之后取消，插件设定每一秒中都会轮询检查一次，如果发现呗取消了，则重复执行三连操作。最终的JavaScript代码如下

```javascript
(function() {
    'use strict';
    window.setInterval(function () {
        // 没点赞则点赞
        if(document.getElementsByClassName('like on')[0] == null) {
            document.querySelector('.like').click();
        }
        // 没投币则投币
        if(document.getElementsByClassName('coin on')[0] == null) {
            document.querySelector('.coin').click();
            document.querySelector('.bi-btn').click();
            alert('休想白嫖！');
        }
        // 没收藏则收藏
        if(document.getElementsByClassName('collect on')[0] == null) {
            document.querySelector('.collect').click();
            document.querySelector('fav-title').click();
            document.querySelector('submit-move').click();
        }
    },1000);
    // Your code here...
})();
```

最终结果如图

![image-20230207203611192](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207203611192.png)

![image-20230207203627291](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207203627291.png)