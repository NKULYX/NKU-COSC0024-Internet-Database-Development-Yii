// ==UserScript==
// @name         BiliBili Auto
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.bilibili.com/video/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=bilibili.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    window.setInterval(function () {
        // 没点赞则点赞
        if(document.getElementsByClassName('like on')[0] == null) {
            document.querySelector('.like').click();
        }
        // 没投币则投币
        if(document.getElementsByClassName('coin on')[0] == null) {
            document.querySelector('.coin').click();
            document.querySelector('.bi-btn').click();
            alert('休想白嫖！');
        }
    },1000);
    // Your code here...
})();