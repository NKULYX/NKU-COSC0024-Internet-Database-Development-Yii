# Homework 3

## WordPress建站过程

1. 首先搭建WordPress所需要的环境即apache+php+MySQL，这里由于之前下载了Xmapp所以实验所需要的开发环境和运行环境都已经配置完成，由于xmapp属于拆箱即用，这里就不过多赘述。

2. 下载WordPress的安装包，将其解压到xmapp的htdocs目录下。[下载链接](https://wordpress.org/download/)

   ![image-20230207211358441](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207211358441.png)

3. 接下来为WordPress创建数据库，使用Navicat，数据库相关信息如下。

   <img src="C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207211517447.png" alt="image-20230207211517447" style="zoom: 67%;" />

4. 接下来需要对WordPress进行数据库连接的相关配置，主要是设置数据库的名称，MySQL用户名和密码等信息。相关配置文件为wp-config-sample.php，相关信息设置如下

   ![image-20230207211752918](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207211752918.png)

5. 完成了前面数据库的连接配置之后，就可以启动wordpress进行初始化配置了。通过xmapp启动apache，在浏览器中访问`localhost/wordpress/wp-admin/setup-config.php`

![image-20230207212152294](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212152294.png)

这里选择语言为`简体中文`

![image-20230207212232707](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212232707.png)

这里点击`现在就开始吧`

![image-20230207212329579](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212329579.png)

在这里完成数据库连接的相关设置，和前面的配置文件中保持一致即可。

![image-20230207212402952](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212402952.png)

这里点击`运行安装程序`即可

![image-20230207212642508](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212642508.png)

这里进行简答的设置即可，注意要记住密码，或者自己改成一个简单的密码。

![image-20230207212658416](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212658416.png)

至此初始化完成，可以看到在数据库中出现了初始化创建的一些数据表

![image-20230207212821687](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212821687.png)

6. 自定义模块设计

   输入用户密码登录显示界面如下，这个界面看起来也还不错

   ![image-20230207212956170](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207212956170.png)

​	这里在插件市场中安装一些插件

![image-20230207213306260](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207213306260.png)

​	比如启用了`你好多莉`插件之后，就可以看到每个页面的右上角都会随机出现一句歌词。

![image-20230207213632739](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207213632739.png)

​	然后我们新建一篇博客，发布后从主页可以看到其内容

![image-20230207214631796](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207214631796.png)