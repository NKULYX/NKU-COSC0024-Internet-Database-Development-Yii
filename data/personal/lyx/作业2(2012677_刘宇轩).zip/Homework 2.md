# Homework 2

## 页面设计

在本次实验中，选用了在线的原型设计工具设计了个人主页的首页

![image-20230207210112070](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207210112070.png)

首页右上角有导航栏，可以在Home，About和Project之间进行跳转，首页会展示一些个人信息，其中右边的图片是一个轮播图，其中能够轮播多张选定的照片。首页下方还能展示自己选定的项目。

## 前后台模板选择

在本次实验中，我们最终从BootstrapMade中选择了前后台模板如下

1. 前台模板

![image-20230207210655325](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207210655325.png)

2. 后台模板

![image-20230207210507684](C:\Users\Lenovo\AppData\Roaming\Typora\typora-user-images\image-20230207210507684.png)